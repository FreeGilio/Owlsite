﻿namespace OWL.Test
{
    public class Class1
    {

    }
}
